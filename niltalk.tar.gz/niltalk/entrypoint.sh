#! /bin/sh

cd /app
./niltalk

tail -f /dev/null
